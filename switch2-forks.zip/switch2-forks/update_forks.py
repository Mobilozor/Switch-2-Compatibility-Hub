#!/usr/bin/env python3
"""Which-one-for-my-device : forks d'émulateurs Switch 2 (Lichii / Eglantine / Orchid / Superbuild…).
Usage : python3 update_forks.py [dossier_sortie]   (export GITHUB_TOKEN=... pour dépasser 60 req/h)
Génère index.html + data.json. Sans réseau/quota, les fiches gardent le dernier snapshot (snap) intégré ci-dessous.
Ajouter un fork : une ligne F(...) dans FORKS. Ajouter un appareil : une ligne dans DEVICES.
"""
import json, os, re, sys, time, urllib.parse, urllib.request
from datetime import datetime, timezone

API = "https://api.github.com"
H = {"Accept": "application/vnd.github+json", "User-Agent": "switch2-forks-tracker"}
if os.environ.get("GITHUB_TOKEN"):
    H["Authorization"] = "Bearer " + os.environ["GITHUB_TOKEN"]

def F(id, name, repo, os_, vendor, games, note, dev=(), base=1, build="release", url=None, snap=None, **kw):
    d = dict(id=id, name=name, repo=repo, os=os_, vendor=vendor, games=games, dev=list(dev), note=note, base=base, build=build,
             url=url or ("https://github.com/" + repo), snap=snap or {})
    d.update(kw)
    return d

A, N, I, ANY = "amd", "nvidia", "intel", "any"
# os: win linux mac android ps5 | games: oot mkw dk pokopia splat hyrule tennis starfox wonder xeno
FORKS = [
    F("lichii", "Lichii", "zortos293/Lichii", ["win", "linux", "mac"], [A, N, ANY], ["oot", "mkw", "tennis", "starfox"], base=3, linuxAsset=True,
      note="Référence communautaire (build 150, PGO). AppImage Linux x86_64/aarch64, DLSS 4.5 et FSR 3.1/4 pour OoT, correctifs AMD/Vulkan réguliers.", snap={"ver": "build 150", "stars": 8208, "date": "2026-11-10"}),
    F("eglantine", "Eglantine (upstream)", "Eglantine-Community/Eglantine", ["win", "linux", "mac"], [ANY], ["hyrule", "xeno"], base=2, linuxAsset=True,
      note="Upstream d’origine (ex-Djihads80) que la plupart des forks rebasent. Bon point de départ « neutre ».", snap={"ver": "v0.1.0-rc3", "stars": 5786, "date": "2026-11-08"}),
    F("superbuild", "Lichii Superbuild", "callme-sy/Lichii-Superbuild", ["win", "linux"], [A, N, ANY], ["oot", "mkw"], base=2, linuxAsset=True,
      note="Build curaté non officiel : AppImage Linux (standard + PGO), correctifs AMD de Nolar/CheezerWheezer, fix crash RDNA2 (#657), libération de la RAM invité, précache shaders. Repli : build stock.", snap={"ver": "v53", "stars": 61, "date": "2026-11-11"}),
    F("nolar", "Nolar-Hack/Lichii", "Nolar-Hack/Lichii", ["linux", "win"], [A], [], base=1, build="source",
      note="Fork source aux correctifs orientés AMD (swap interval vidéo, RAM invité libérée à l’arrêt, seuil de cache de textures). Intégré au Superbuild ; releases non vérifiées : à compiler."),
    F("orchid", "Orchid", "MythosOfs/Orchid", ["win", "linux", "mac"], [A], ["tennis", "xeno", "hyrule", "pokopia", "wonder"], base=2, linuxAsset=True,
      note="Indépendant, correctifs shaders/GPU AMD (développé sur RX 9070 XT), recommandé pour AMD sous Linux (RADV) et Mario Tennis/Xenoblade/Hyrule Warriors.", snap={"ver": "v0.9.5", "stars": 411, "date": "2026-11-10"}),
    F("cheezy", "CheezyEmu (ex AMD Superior)", "CheezerWheezer/CheezyEmu", ["win", "linux", "mac"], [A], ["oot"], base=1, fsr4=True,
      note="Spécial AMD : FSR 4 / FSR 3.1, frame generation AMD x2, packs de shaders sur disque, correctifs de crash RDNA.", snap={"ver": "build-10", "stars": 13, "date": "2026-11-09"}),
    F("fritchii", "Fritchii (Frizti)", "Frizti/Fritchii", ["win"], [N, A], ["oot"], base=2, dlss=True,
      note="OoT uniquement, Windows x64 : précompile 120 461 shaders (NVIDIA et AMD), DLSS, mode Ctrl+U 90–165 Hz, gestionnaire de sauvegardes.", snap={"ver": "v5.8.3", "stars": 3389, "date": "2026-11-11"}),
    F("ally", "Lichii Ally", "Syyrhc/Lichii-Ally", ["win"], [A], ["oot"], dev=["ally", "legion"], base=1,
      note="Pour ROG Xbox Ally X / Ally X / Z1E / Legion Go : édition AVX-512 (Zen 4/5) ou AVX2 (Z2 A, Z2 Go), FSR 3.1 auto, VRR 40 fps, manette liée au 1er lancement. Windows seulement.", snap={"ver": "v4"}),
    F("selevet", "Selevet Eglantine", "sylvieistaken/selevet-eglantine", ["win"], [A, I], ["dk", "oot"], base=1,
      note="Builds perf PGO+ThinLTO calés Zen 3, OoT sur AMD (dont RX 500) et Intel Arc, frame gen FSR 3 activée par défaut.", snap={"ver": "performance-9", "stars": 257}),
    F("smiley", "SmileyTatsu/Eglantine", "SmileyTatsu/Eglantine", ["win", "linux", "mac"], [A], ["mkw"], base=1,
      note="Spécialiste Mario Kart World (fix fréquence d’images, limite de cache de textures selon la VRAM).", snap={"ver": "build-20", "stars": 24, "date": "2026-11-06"}),
    F("pokedinner", "PokeDinner", "Franseven/PokeDinner-a-Eglantine-Fork", ["win", "linux", "mac"], [ANY], ["pokopia", "dk", "splat"], base=1,
      url="https://git.eden-emu.dev/Franseven/PokeDinner-a-Eglantine-Fork", note="Labo jeux : Pokopia, Bananza (30 fps), Splatoon Raiders. Gitea, Linux/macOS surtout en 2.5.0.", snap={"ver": "2.7.7", "stars": 98, "date": "2026-11-05"}),
    F("notsapinho", "notsapinho/Eglantine", "notsapinho/Eglantine", ["win", "linux"], [ANY], ["pokopia"], note="Build simple Pokopia (x86_64 AVX2 requis).", snap={"ver": "build-24", "stars": 10}),
    F("rdenno", "rdenno/Eglantine", "rdenno/Eglantine", ["win"], [ANY], ["hyrule", "tennis"], note="Branche perf Hyrule Warriors + correctifs Mario Tennis Fever.", snap={"ver": "build-8", "stars": 7}),
    F("zendnevs", "ZendNevs Eglantine", "ZendNevs/Eglantine-ZendNevs", ["win"], [ANY], ["mkw", "pokopia"], note="Fusion Selevet + Eglantine + PokeDinner : FSR 3 / LSFG frame generation, DynamicFPS, lock 30 fps MKW.", snap={"ver": "v2.0.5", "stars": 112}),
    F("hortensia", "Hortensia", "justr4mzi/hortensia", ["win", "linux", "mac"], [A, ANY], ["oot"], note="Agrégat des meilleurs patchs (Lichii, Selevet, Orchid, SmileyTatsu…) : lane shuffle AMD d’Orchid, perfs OoT.", snap={"ver": "v0.2.0", "stars": 31}),
    F("deckfork", "Eglantine-steamdeck", "MFS-code/Eglantine-steamdeck", ["linux"], [A], [], dev=["deck"], base=1,
      note="Fork Steam Deck : fences mémoire pour APU UMA 16 Go, correctifs command-stream et shaders trouvés sur SteamOS."),
    F("deckoled", "Eglantine Deck OLED (RufflezAU)", "RufflezAU/Eglantine", ["linux"], [A], ["oot"], dev=["deck"], base=1, linuxAsset=True,
      note="Builds de test Steam Deck OLED (branche test/deck-oled, AppImage x86_64, RADV Van Gogh) pour OoT. Test, pas stable."),
    F("conong", "Lichii OoT AMD (conongnang)", "conongnang/Lichii", ["win", "linux", "mac"], [A], ["oot"], base=1, linuxAsset=True,
      note="Branche perf/oot-amd-120 : AppImage Linux x86_64 (PGO), fix bloom/brouillard et freeze Castle Town, Texture Pool x2."),
    F("sharkiix", "Lichii sharkiix", "Shakoquo/Lichii-sharkiix-version", ["win"], [A], ["oot"], note="Surtout GPU AMD, optimisé OoT, réglages dans SHARKIIX.md (plateformes non précisées : vérifier la page releases)."),
    F("mja00", "Lichii OOT (mja00)", "mja00/Lichii", ["win", "linux", "mac"], [ANY], ["oot"], linuxAsset=True, note="Releases « Lichii OOT » v2.x : AppImage Linux, updater intégré, bascule 60/30 fps (pacer Windows seulement)."),
    F("aubepine", "Aubépine", "pattex67/Aubepine", ["win"], [ANY], ["starfox", "wonder"], note="PokeDinner + Eglantine nx2, repose sur Lichii depuis le 8 nov : Star Fox et Yoshi."),
    F("droplet", "Droplet (eden-nx2)", None, ["win", "linux"], [ANY], ["mkw"], url="https://gitlab.com/seighttt/droplet", note="GitLab : serveurs privés pour MKW en ligne/LAN entre émulateurs. Binaires Windows et Arch Linux, parfois source seule."),
    F("hokkaido", "Hokkaido (Android)", "pavelgajdo/Hokkaido", ["android"], [A], ["oot", "pokopia"], base=2,
      note="Seul fork Android ARM64 trouvé (Android 13+, Vulkan 1.3). Validé surtout sur Samsung Exynos/Xclipse (AMD) ; aucun rapport Snapdragon trouvé.", snap={"ver": "android-0.6.2", "stars": 209, "date": "2026-11-10"}),
    F("ps5a", "EglantinePS5 (heydemoura)", "heydemoura/EglantinePS5", ["ps5"], [A], [], base=2, note="Portage PS5 non officiel d’Eglantine (homebrew), très expérimental."),
    F("ps5b", "Eglantine-PS5 (viejunerd)", "viejunerd/Eglantine-PS5-", ["ps5"], [A], [], note="Autre portage PS5 : frontend + patchs du cœur Eglantine (nx2)."),
    F("nxnative", "nxnative", None, ["mac"], [A, ANY], [], url="https://github.com/riyadhHDA/wichforks", note="Pas un émulateur : jeux Switch 2 en apps macOS à partir d’un NUP, source seulement (cité dans le guide wichforks)."),
]
MICRO = [("jojo-chaechae/Eglantine", "GPU-split submit et macro hand-back (repris par le Superbuild)"), ("Duck912/Eglantine-ducky", "Fix réticule OoT / pointeur near-leaf"),
         ("EndingVE/Lichii-Frizti", "Fork du fork Frizti"), ("kiv9393/Eglantine-Lichii", "Fork de Lichii"), ("christianball123/Lichii", "Fork de Lichii"),
         ("nyakuoff/Lichii-oot", "Fork de Lichii (OoT)"), ("EddizEge/Anka", "Fork perf DK, Windows 10/11"), ("RufflezAU/Eglantine", "voir Deck OLED"),
         ("Chungus Emulation", "Fork Eglantine Linux v0.2.0, inactif")]

def D(id, label, group, apu, ram, os_, vendor, arch, avx512, tags=(), short=None, tips=()):
    return dict(id=id, label=label, group=group, apu=apu, ram=ram, os=os_, vendor=vendor, arch=arch, avx512=avx512, tags=list(tags), short=short or label, tips=list(tips))

HH = "Consoles et handhelds"; GP = "Cartes graphiques"
DEVICES = [
    D("deck_lcd", "Steam Deck LCD", HH, "Van Gogh : Zen 2 + RDNA2 8 CU", 16, ["linux", "win"], A, "rdna2", False, ["deck"], "Steam Deck"),
    D("deck_oled", "Steam Deck OLED", HH, "Van Gogh : Zen 2 + RDNA2 8 CU", 16, ["linux", "win"], A, "rdna2", False, ["deck"], "Steam Deck"),
    D("ally_z1", "ROG Ally (Z1)", HH, "Zen 4 + RDNA3 4 CU", 16, ["win", "linux"], A, "rdna3", True, ["ally"], "ROG Ally"),
    D("ally_z1e", "ROG Ally (Z1 Extreme)", HH, "Zen 4 + RDNA3 12 CU", 16, ["win", "linux"], A, "rdna3", True, ["ally"], "ROG Ally"),
    D("ally_x", "ROG Ally X", HH, "Z1 Extreme, RDNA3 12 CU", 24, ["win", "linux"], A, "rdna3", True, ["ally"], "ROG Ally"),
    D("xally", "ROG Xbox Ally (Z2 A)", HH, "Z2 A : Zen 2 + RDNA2", 16, ["win", "linux"], A, "rdna2", False, ["ally"], "ROG Xbox Ally"),
    D("xallyx", "ROG Xbox Ally X (Z2 Extreme)", HH, "Zen 5 + RDNA3.5 16 CU", 24, ["linux", "win"], A, "rdna35", True, ["ally"], "ROG Xbox Ally X"),
    D("lgo", "Legion Go (Z1 Extreme)", HH, "Zen 4 + RDNA3 12 CU", 16, ["win", "linux"], A, "rdna3", True, ["legion"], "Legion Go"),
    D("lgos", "Legion Go S (Z2 Go)", HH, "Z2 Go : Zen 3+ + RDNA2 12 CU", 16, ["win", "linux"], A, "rdna2", False, ["legion"], "Legion Go S"),
    D("lgo2", "Legion Go 2 (Z2 Extreme)", HH, "Zen 5 + RDNA3.5 16 CU", 32, ["win", "linux"], A, "rdna35", True, ["legion"], "Legion Go 2"),
    D("ps5", "PlayStation 5 (homebrew)", HH, "Zen 2 + RDNA2 36 CU, GDDR6", 16, ["ps5"], A, "rdna2", False, [], "PS5", ["Très expérimental, uniquement sur console avec homebrew."]),
    D("thor", "AYN Thor (Snapdragon 8 Gen 2)", HH, "ARM64, GPU Adreno", 12, ["android"], "qcom", "adreno", False, [], "AYN Thor", ["Android : Hokkaido est le seul fork trouvé et il vise surtout Exynos/Xclipse ; sur Adreno, pilote Vulkan personnalisé probablement nécessaire, aucun rapport trouvé."]),
    D("rtx50", "NVIDIA RTX 50 (5060 à 5090)", GP, "Blackwell", None, ["win", "linux"], N, "rtx", False),
    D("rtx40", "NVIDIA RTX 40 (4060 à 4090)", GP, "Ada", None, ["win", "linux"], N, "rtx", False),
    D("rtx30", "NVIDIA RTX 30 (3050 à 3090)", GP, "Ampere", None, ["win", "linux"], N, "rtx", False),
    D("rtx20", "NVIDIA RTX 20 / GTX 16", GP, "Turing", None, ["win", "linux"], N, "rtx", False),
    D("gtx10", "NVIDIA GTX 10 (1050 à 1080 Ti)", GP, "Pascal : vieux, mesh shaders absents", None, ["win", "linux"], N, "gtx", False),
    D("rx9000", "AMD RX 9000 (9060 XT / 9070 XT)", GP, "RDNA4", None, ["win", "linux"], A, "rdna4", False),
    D("rx7000", "AMD RX 7000 (7600 à 7900 XTX)", GP, "RDNA3", None, ["win", "linux"], A, "rdna3", False),
    D("rx6000", "AMD RX 6000 (6600 à 6950 XT)", GP, "RDNA2", None, ["win", "linux"], A, "rdna2", False),
    D("rx5000", "AMD RX 5000 (5500 à 5700 XT)", GP, "RDNA1", None, ["win", "linux"], A, "rdna1", False),
    D("rx500", "AMD RX 400/500, Vega", GP, "Polaris/GCN : limite", None, ["win", "linux"], A, "gcn", False),
    D("hx370", "Laptop Ryzen AI 9 HX 370 / 780M", GP, "iGPU RDNA3.5/RDNA3", None, ["win", "linux"], A, "rdna35", True),
    D("arcb", "Intel Arc B-series (B570/B580)", GP, "Battlemage", None, ["win", "linux"], I, "arc", False),
    D("arca", "Intel Arc A-series (A380 à A770)", GP, "Alchemist", None, ["win", "linux"], I, "arc", False),
    D("apple", "Mac Apple Silicon (M1 à M4)", GP, "Metal/MoltenVK", None, ["mac"], "apple", "apple", False, [], "Mac Apple Silicon", ["Builds macOS arm64 expérimentaux : Lichii, Eglantine, Orchid (Fritchii n’en fait pas)."]),
]
PR_REPOS = ["zortos293/Lichii", "Eglantine-Community/Eglantine", "MythosOfs/Orchid", "callme-sy/Lichii-Superbuild"]
FORK_BASES = ["zortos293/Lichii", "Eglantine-Community/Eglantine"]
KW = {"AMD": r"\bamd\b", "RADV": r"\bradv\b", "Linux": r"\blinux\b", "Steam Deck": r"steam ?deck", "SteamOS": r"steamos", "Ally": r"\bally\b", "FSR": r"\bfsr\b", "Vulkan": r"vulkan"}

def get(path, **q):
    url = API + path + ("?" + urllib.parse.urlencode(q) if q else "")
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=H), timeout=25) as r:
            return json.load(r)
    except Exception as e:
        print("!", path, e, file=sys.stderr)
        return None

def kws(t):
    t = (t or "").lower()
    return [k for k, rx in KW.items() if re.search(rx, t)]

def days_since(iso):
    return (datetime.now(timezone.utc) - datetime.fromisoformat(iso.replace("Z", "+00:00"))).days if iso else 999

def build():
    forks, seen = [], set()
    for f in FORKS:
        f = dict(f); f["live"] = False; f["release"] = None
        if f["repo"]:
            seen.add(f["repo"].lower())
            r = get(f"/repos/{f['repo']}")
            if r:
                rel = (get(f"/repos/{f['repo']}/releases", per_page=1) or [None])[0]
                lx = [a["name"] for a in rel["assets"] if re.search(r"appimage|linux", a["name"], re.I)] if rel else []
                f.update(live=True, stars=r["stargazers_count"], forks=r["forks_count"], pushed=r["pushed_at"], archived=r["archived"],
                         release={"name": rel["name"] or rel["tag_name"], "date": rel["published_at"], "url": rel["html_url"], "pre": rel["prerelease"], "linux": lx[:3]} if rel else None)
                if rel:
                    f["linuxAsset"] = bool(lx)
        forks.append(f)
    prs = []
    for repo in PR_REPOS:
        res = get("/search/issues", q=f'repo:{repo} is:pr (AMD OR RADV OR Linux OR "Steam Deck" OR SteamOS OR Ally)', sort="updated", per_page=40)
        time.sleep(2.5)
        for it in (res or {}).get("items", []):
            prs.append({"repo": repo, "n": it["number"], "title": it["title"], "url": it["html_url"], "user": it["user"]["login"], "updated": it["updated_at"],
                        "state": "merged" if (it.get("pull_request") or {}).get("merged_at") else it["state"], "kw": kws(it["title"] + " " + (it.get("body") or "")[:1500])})
    found = {}
    for base in FORK_BASES:
        for x in get(f"/repos/{base}/forks", sort="stargazers", per_page=50) or []:
            if x["full_name"].lower() in seen or days_since(x["pushed_at"]) > 30:
                continue
            found[x["full_name"]] = {"repo": x["full_name"], "url": x["html_url"], "stars": x["stargazers_count"], "pushed": x["pushed_at"],
                                     "desc": x.get("description") or "", "kw": kws(x["full_name"] + " " + (x.get("description") or "")), "from": base}
    return {"generated": datetime.now(timezone.utc).isoformat(timespec="minutes"), "devices": DEVICES, "forks": forks, "micro": MICRO,
            "prs": sorted(prs, key=lambda p: p["updated"], reverse=True), "found": sorted(found.values(), key=lambda x: -x["stars"])}

TEMPLATE = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "template.html"), encoding="utf-8").read() if os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), "template.html")) else None

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    os.makedirs(out, exist_ok=True)
    data = build()
    json.dump(data, open(os.path.join(out, "data.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if TEMPLATE is None:
        sys.exit("template.html introuvable à côté du script")
    open(os.path.join(out, "index.html"), "w", encoding="utf-8").write(TEMPLATE.replace("__DATA__", json.dumps(data, ensure_ascii=False).replace("</", "<\\/")))
    live = sum(1 for f in data["forks"] if f["live"])
    print(f"OK : {len(data['forks'])} forks ({live} avec stats live), {len(data['prs'])} PR, {len(data['found'])} découverts -> {out}/index.html")
